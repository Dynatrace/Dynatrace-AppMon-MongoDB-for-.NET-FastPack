﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MongoDB2.Model;

namespace MongoDB2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        
        private void btnCreateData_Click(object sender, EventArgs e)
        {
            MyCompany.CreateData();
        }

        private void btnGetDepartments_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = MyCompany.GetDepartments();
        }

        private void btnGetEmployees_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = MyCompany.GetEmployees();
        }

        private void btnDeleteDepartments_Click(object sender, EventArgs e)
        {
            MyCompany.DeleteDepartments();
        }

        private void btnDeleteEmployees_Click(object sender, EventArgs e)
        {
            MyCompany.DeleteEmployees();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MyCompany.RunLINQ();
        }

    }
}
