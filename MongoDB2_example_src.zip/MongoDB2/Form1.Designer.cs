﻿namespace MongoDB2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnDeleteDepartments = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnDeleteEmployees = new System.Windows.Forms.Button();
            this.btnGetEmployees = new System.Windows.Forms.Button();
            this.btnGetDepartments = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnCreateData = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnDeleteDepartments
            // 
            this.btnDeleteDepartments.Location = new System.Drawing.Point(429, 14);
            this.btnDeleteDepartments.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnDeleteDepartments.Name = "btnDeleteDepartments";
            this.btnDeleteDepartments.Size = new System.Drawing.Size(151, 28);
            this.btnDeleteDepartments.TabIndex = 6;
            this.btnDeleteDepartments.Text = "Delete Departments";
            this.btnDeleteDepartments.UseVisualStyleBackColor = true;
            this.btnDeleteDepartments.Click += new System.EventHandler(this.btnDeleteDepartments_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(963, 365);
            this.dataGridView1.TabIndex = 0;
            // 
            // btnDeleteEmployees
            // 
            this.btnDeleteEmployees.Location = new System.Drawing.Point(588, 15);
            this.btnDeleteEmployees.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnDeleteEmployees.Name = "btnDeleteEmployees";
            this.btnDeleteEmployees.Size = new System.Drawing.Size(151, 28);
            this.btnDeleteEmployees.TabIndex = 7;
            this.btnDeleteEmployees.Text = "Delete Employees";
            this.btnDeleteEmployees.UseVisualStyleBackColor = true;
            this.btnDeleteEmployees.Click += new System.EventHandler(this.btnDeleteEmployees_Click);
            // 
            // btnGetEmployees
            // 
            this.btnGetEmployees.Location = new System.Drawing.Point(296, 14);
            this.btnGetEmployees.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnGetEmployees.Name = "btnGetEmployees";
            this.btnGetEmployees.Size = new System.Drawing.Size(125, 28);
            this.btnGetEmployees.TabIndex = 5;
            this.btnGetEmployees.Text = "Get Employees";
            this.btnGetEmployees.UseVisualStyleBackColor = true;
            this.btnGetEmployees.Click += new System.EventHandler(this.btnGetEmployees_Click);
            // 
            // btnGetDepartments
            // 
            this.btnGetDepartments.Location = new System.Drawing.Point(157, 15);
            this.btnGetDepartments.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnGetDepartments.Name = "btnGetDepartments";
            this.btnGetDepartments.Size = new System.Drawing.Size(131, 28);
            this.btnGetDepartments.TabIndex = 4;
            this.btnGetDepartments.Text = "Get Departments";
            this.btnGetDepartments.UseVisualStyleBackColor = true;
            this.btnGetDepartments.Click += new System.EventHandler(this.btnGetDepartments_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.btnDeleteEmployees);
            this.panel1.Controls.Add(this.btnDeleteDepartments);
            this.panel1.Controls.Add(this.btnGetEmployees);
            this.panel1.Controls.Add(this.btnGetDepartments);
            this.panel1.Controls.Add(this.btnCreateData);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(963, 85);
            this.panel1.TabIndex = 2;
            // 
            // btnCreateData
            // 
            this.btnCreateData.Location = new System.Drawing.Point(16, 15);
            this.btnCreateData.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnCreateData.Name = "btnCreateData";
            this.btnCreateData.Size = new System.Drawing.Size(133, 28);
            this.btnCreateData.TabIndex = 3;
            this.btnCreateData.Text = "Create Data";
            this.btnCreateData.UseVisualStyleBackColor = true;
            this.btnCreateData.Click += new System.EventHandler(this.btnCreateData_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.dataGridView1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 85);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(963, 365);
            this.panel2.TabIndex = 3;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(747, 15);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(135, 27);
            this.button1.TabIndex = 8;
            this.button1.Text = "Run LINQ";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(963, 450);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnDeleteDepartments;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnDeleteEmployees;
        private System.Windows.Forms.Button btnGetEmployees;
        private System.Windows.Forms.Button btnGetDepartments;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnCreateData;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button1;
    }
}

